__NOTICE__

__I have been granted control of this Add-on. I will be creating a new version for Kodi 18.__


![TvTunes](icon.png)

TvTunes has grown over time and is now more than a simple theme player for TV Shows, some of the features include:
* Play themes while navigating TV Shows
* Play themes while navigating Movies
* Play themes while navigating Music Videos
* Play video themes in addition to audio themes

It is a feature rich and very configurable addon with numerous settings to allow you to fine-tune it to your own requirements.

More details, and how to use the addon can be viewed on the wiki:

[Add-on:TvTunes](https://github.com/latts9923/service.tvtunes/wiki)

